
Create Table Shippers (
ShipperID Int Primary Key Not NUll,
ShipperName	Varchar(255),
Phone Varchar(255)
);


Insert Into Shippers(ShipperID,ShipperName,Phone)
Values
(1,'Speedy Express','(503) 555-9831'),
(2,'United Package','(503) 555-3199'),
(3,'Federal Shipping','(503) 555-9931');
